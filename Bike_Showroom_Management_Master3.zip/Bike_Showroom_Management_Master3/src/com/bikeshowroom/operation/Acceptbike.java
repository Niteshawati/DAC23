package com.bikeshowroom.operation;

import java.util.Scanner;

import com.bikeshowroom.domain.Bike;

public class Acceptbike 
{ 
	public static Scanner scan=new Scanner(System.in); 

	public static Bike[] getBikelist() 
	{
		Bike []arr=new Bike[3];
		
		arr[0]=new Bike("Clasic","250","Black",221000f);
		arr[1]=new Bike("Electra","150","Green",251000f);
		arr[2]=new Bike("Hunter","450","Grey_black",231000f);
		
		return arr;
		
	}

	public static Bike[] acceptbike()
   {

		Bike []arr=new Bike[1];
		arr[0]=new Bike();
		//scan.nextLine();
		System.out.println("Enter model");
		arr[0].setModelNumber(scan.nextLine());
		System.out.println("Enter enginecapacity");
		arr[0].setEnginecapacity(scan.nextLine());
		System.out.println("Enter colour");
		arr[0].setColour(scan.nextLine());
		System.out.println("Enter price");
		arr[0].setPrice(scan.nextFloat());
		scan.nextLine();
		return arr;
		
	}

}
