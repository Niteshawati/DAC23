package com.bikeshowroom.operation;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import com.bikeshowroom.domain.Bike;
import com.bikeshowroom.domain.Customer;
import com.bikeshowroom.domain.Showroom;

public class Testshowroom 
{
    private static Scanner scan=new Scanner(System.in);
	private static List<Bike> Bikelist=null;
	private static LinkedList<Customer> cust=new LinkedList<>();

	public void settest(List Bikelist) 
	{
		this.Bikelist=Bikelist;
		
	}

	public static  void Add(Bike []arr) 
	{
		if(Bikelist!=null)
		{
			for(Bike bike :arr)
			{
				Bikelist.add(bike);
			}
			
		}
		
	}

	public static void findBikes(String model) throws InterruptedException
	{
		if(Bikelist!=null)
		{
			Bike rem=new Bike();
			rem.setModelNumber(model);
				if(Bikelist.contains(rem))
				{      int index=Bikelist.indexOf(rem);
				        Bike b=Bikelist.get(index);
				      System.out.println(b);
				      System.out.println("if you want to Book Bike press Yes/No");
					  String ch=scan.next();
					  if(ch.equalsIgnoreCase("YES"))
					  {
						  
						  Testshowroom.BookBike(b);
					  }
				}
			
		}
		
	}

	public static boolean RemoveBikes(String model) 
	{
		if(Bikelist!=null)
		{
			Bike rem=new Bike();
			rem.setModelNumber(model);
				if(Bikelist.contains(rem))
				Bikelist.remove(rem);
			       return true;
		}
		 return false;
			
	}

	public static void BookBike(Bike b) throws InterruptedException 
	{
		scan.nextLine();
		Customer booking=new Customer();
	   System.out.println("Enter customer name");
	   booking.setName(scan.nextLine());
	   System.out.println("Enter customer Address");
	   booking.setAddress(scan.nextLine());
	   System.out.println("Enter customer m_no;");
	   booking.setM_no(scan.nextLine());
	   booking.setCb(b);
	   cust.addFirst(booking);
	   System.out.println("Thank you for Booking ");
	   Thread.sleep(500);
	   System.out.println("visit again !!!! ");
	   
	   
	}

	public static void ShowALLBike() 
	{
		System.out.println();
		System.out.println("********************************************************************************************************************");
		for(Bike b:Bikelist)
			System.out.println(b);
		System.out.println("*********************************************************************************************************************");
	}

	public static void ShowALLBookings() 
	{
		System.out.println("******************************************* Booking details *******************************************************");
		for( Customer bk:cust)
			System.out.println(bk);
		 
		 System.out.println("*******************************************************************************************************************");
	}

	public static void filter(Comparator<Bike> comparator) 
	{
		
		Bikelist.sort(comparator);
		for(Bike b:Bikelist)
			System.out.println(b);
		System.out.println();
		 System.out.println("*******************************************************************************************************************");
		
	}
      
}


/*
    String name;
	String Address;
	String m_no;
	String Email;
	Bike cb;
 */
