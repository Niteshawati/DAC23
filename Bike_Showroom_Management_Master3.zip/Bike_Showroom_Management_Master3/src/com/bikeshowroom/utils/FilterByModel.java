package com.bikeshowroom.utils;

import java.util.Comparator;

import com.bikeshowroom.domain.Bike;

public class FilterByModel implements Comparator<Bike>
{

	@Override
	public int compare(Bike B1, Bike B2) 
	{
	
		return B1.getModelNumber().compareTo(B2.getModelNumber());
	}

}
