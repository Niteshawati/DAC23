package com.bikeshowroom.utils;

import lombok.NoArgsConstructor;

public class PasswardMismatchException extends Exception 
{
	public PasswardMismatchException(String msg)
	{
		System.out.println();
		System.out.println(msg);
		System.out.println();
		System.out.println("***************************");
		System.out.println("**  please Try again !!!  **");
		System.out.println("***************************");
		System.out.println();
	}
}
