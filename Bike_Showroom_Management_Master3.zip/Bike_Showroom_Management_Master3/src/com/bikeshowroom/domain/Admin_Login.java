package com.bikeshowroom.domain;

import java.util.Scanner;

public class Admin_Login
{
   private static Scanner sc=new Scanner(System.in);
   final static String userId="admin@2412";
   final static String Passward="Swami@1997";

   public static boolean Login() 
   {
	    System.out.println("Enter user ID");
	    String user_ID=sc.nextLine();
	    System.out.println("Enter Passward ");
	    String passward=sc.nextLine();
	    if(user_ID.equals(userId)&&passward.equals(Passward))
	    {
	    	System.out.println("**********************************************");
	    	System.out.println("****        LOGIN SUCCESSFULL             ****");
	    	System.out.println("**********************************************");
	    	
	    	System.out.println();
	    	return true;
	    }
	            
	   
	        return false;
   }
   
   
}
