package com.bikeshowroom.domain;


import java.util.Iterator;
import java.util.Objects;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@Setter
@Getter
public class Bike implements Comparable<Bike>
{
  final static String Bike_name="Royal Enfield";
  private String modelNumber;
  private String enginecapacity;
  private String colour;
  private float price;
  
  
public Bike(String modelNumber, String enginecapacity, String colour,float price) 
{
	
	this.modelNumber = modelNumber;
	this.enginecapacity = enginecapacity;
	this.colour = colour;
	this.price=price;
}

@Override
public int hashCode() {
	return Objects.hash(modelNumber);
}



@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Bike other = (Bike) obj;
	return Objects.equals(modelNumber, other.modelNumber);
}

  
  @Override
	public String toString() 
  {
		
		return String.format("%-20s%-20s%-20s%-20s%-10.3f",Bike.Bike_name,this.modelNumber,this.enginecapacity,this.colour,this.price);
	}

@Override
public int compareTo(Bike o) 
{
	
	return (int) (this.price-o.price);
}





  
}
