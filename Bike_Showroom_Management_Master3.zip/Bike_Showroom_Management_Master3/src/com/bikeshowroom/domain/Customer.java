package com.bikeshowroom.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@Setter
@Getter
public class Customer 
{
	String name;
	String Address;
	String m_no;
	String Email;
	Bike cb;
	
	public Customer(String name, String address, String m_no, String email, Bike cb) {
		super();
		this.name = name;
		Address = address;
		this.m_no = m_no;
		Email = email;
		this.cb = cb;
	}

	@Override
	public String toString() 
	{
		 return String.format("%-15s%-15s%-15s%-15s%-15s%-10s",this.name,this.Address,this.m_no,this.cb.Bike_name,this.cb.getModelNumber(),this.cb.getEnginecapacity());
	}
 
	
}
