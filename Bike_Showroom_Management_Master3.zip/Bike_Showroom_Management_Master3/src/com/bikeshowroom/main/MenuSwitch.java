package com.bikeshowroom.main;

import java.util.Comparator;
import java.util.Scanner;

import com.bikeshowroom.domain.Bike;
import com.bikeshowroom.operation.*;
import com.bikeshowroom.utils.*;
public class MenuSwitch 
{
	
	private static Scanner scan=new Scanner(System.in); 
	
	private static int Menulist() 
	{
		System.out.println("********************************************");
		System.out.println("*********       MAIN MENU          *********");
		System.out.println("********************************************");
		
		
		System.out.println("0.Exit");
		System.out.println("1.Add bike");
		System.out.println("2.find bike");
		System.out.println("3.Remove bike");
		System.out.println("4.Book bike");
		System.out.println("5.print Bike data");
		System.out.println("6.Show Booking");
		
		return scan.nextInt();
		
		
	}
	
	private static void Removestatus(boolean removestatus) 
	{
		if(removestatus)
			System.out.println("Bike is removed");
		else
			System.out.println("Bike is not found");
		
	}
	
	private static int Submenu() 
	{
		
		System.out.println("1.filter By model name");
		System.out.println("2.filter By Engine capacity");
		System.out.println();
		
		System.out.println("Enter choice");
		return scan.nextInt();
		
		
	}
	
	public static void Swichlist() throws InterruptedException 
	{
		int choice;
		while((choice=MenuSwitch.Menulist())!=0)
		{
			switch (choice) 
			{
			case 1:
					Testshowroom.Add(Acceptbike.acceptbike());
					System.out.println(" new Bike added ");
					break;
			case 2:
				    System.out.println("Enter Bike model");
				    scan.nextLine();
					Testshowroom.findBikes(scan.nextLine());
					break;
			case 3:
				System.out.println("Enter Bike model");
				scan.nextLine();
				boolean Removestatus= Testshowroom.RemoveBikes(scan.nextLine());
				MenuSwitch.Removestatus(Removestatus);
				System.out.println();
				
					break;
			case 4:
					System.out.println("Enter Bike model");
					scan.nextLine();
					Testshowroom.findBikes(scan.nextLine());
					break;
			case 5:
				       int subchoice=0;
				       Comparator<Bike> comparator=null;
				     while((subchoice=MenuSwitch.Submenu())!=0)
				     {
				    	 
				    	 switch (subchoice) 
				    	 {
				    	 	case 1:
				    	 		comparator=new FilterByModel();
				    	 		break;
				    	 	case 2:
				    	 		comparator=new FilterByEngincapacity();
							break;
						default:
							break;
						}
				    	 Testshowroom.filter(comparator);
				     }
				    
				  	//Testshowroom.ShowALLBike();
					break;
			case 6:
				  Testshowroom.ShowALLBookings();
					break;
	
			default:
				break;
			}
		}
		
	}

	
	
}
