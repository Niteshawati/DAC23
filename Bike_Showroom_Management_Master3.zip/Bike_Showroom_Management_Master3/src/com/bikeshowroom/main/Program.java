package com.bikeshowroom.main;
import java.util.ArrayList;
import java.util.Scanner;

import com.bikeshowroom.domain.*;
import com.bikeshowroom.operation.*;
import com.bikeshowroom.utils.PasswardMismatchException;

public class Program 
{
	
	private static Testshowroom set=new Testshowroom();
	Acceptbike a=new Acceptbike();
	
	
	public static void main(String[] args) 
	{
		while(true) {
		try {
			set.settest(new ArrayList<>());
			Bike []arr=Acceptbike.getBikelist();
			  arr= Acceptbike.getBikelist();
			  Testshowroom.Add(arr);
			  
			  if(Admin_Login.Login())
			  MenuSwitch.Swichlist();
			  throw new PasswardMismatchException("Enter Correct User_name & Passward !!!");
		} catch (InterruptedException e) 
		{
			
			e.printStackTrace();
		}
		catch (PasswardMismatchException  e) 
		{
			
			//System.out.println(e.getMessage());
		}
		

	}
	}

	

	

	
	

}
